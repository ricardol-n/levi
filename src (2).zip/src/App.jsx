import React,{useState} from 'react'
import './App.css';
import {Sidebar} from './Sidebar.jsx';
import { BrowserRouter as Router, Routes,Route,useLocation,Navigate } from 'react-router-dom';
import Header from './Header.jsx';
import { InvestmentPlans,InvestLog } from './pages/Reports.jsx';
import {Deposit,DepositLog} from './pages/Products.jsx';
import {Withdraw,WithdrawLog} from './pages/Team.jsx';
import {Transfer,TransferMoneyLog,InterestLog,TransactionLog} from './pages/Messages.jsx';
import {Setting,Logout} from './pages/Setting.jsx';
import {RefferalLog} from './pages/Refferal.jsx';
import {TwoFactor} from './pages/TwoFactor.jsx';
import {DepositConfirmationPage} from "./pages/DepoistConfrim.jsx"
import { Charts } from './pages/Charts.jsx';
import  Register  from './Register.jsx';
import Dashboard  from './Dashboard.jsx';



function App() {

  const [isRegistered, setIsRegistered] = useState(false);

  
  return (
    
    <Router>

    
    
      <Routes>
      {!isRegistered ? (
                    <Route path="/" element={<Register onRegister={() => setIsRegistered(true)} />} />
                ) : (
                    <>
            
            <Route path="/*" element={<Dashboard/>}/>
            <Route path="/dashboard" element={<> <Header /> <Sidebar /> <Dashboard />
            </>
          } />
            <Route path='/investmentplans' exact Component={InvestmentPlans} />
            <Route path='/InvestLog' exact Component={InvestLog} />
            <Route path='/deposit' exact Component={Deposit}/>
            <Route path='/depositlog' exact Component={DepositLog}/>
            <Route path='/withdraw' exact Component={Withdraw}/>
            <Route path='/withdrawlog' exact Component={WithdrawLog}/>
            <Route path='/transfer' exact Component={Transfer}/>
            <Route path='/transfer/transferlog' exact Component={TransferMoneyLog}/>
            <Route path='/transfer/interestlog' exact Component={InterestLog}/>
            <Route path='/transfer/transactionlog' exact Component={TransactionLog}/>
            <Route path='/refferallog' exact Component={RefferalLog}/>
            <Route path='/twofactor' exact Component={TwoFactor}/>
            <Route path='/setting/profile' exact Component={Setting}/>
            <Route path='/setting/logout' exact Component={Logout}/>
            <Route path='/depositconfirmationpage' exact Component={DepositConfirmationPage}/>
            <Route path='/Charts' exact Component={Charts}/>  
        </>
       )}
      </Routes>
    
    </Router>
    
  )
}

export default App;
