// pages/DepositConfirmationPage.js
import React, { useContext, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { BalanceContext } from "../BalanceContext";
import MessageBox from "./MessageBox";

export const DepositConfirmationPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { balance, setBalance, addTransaction } = useContext(BalanceContext);

  const [showMessageBox, setShowMessageBox] = useState(false);
  const [message, setMessage] = useState("");
  const [isVerified, setIsVerified] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  if (!location.state) {
    return <p className="error-message">No deposit details available. Please start again.</p>;
  }

  const { address, amount, charge, method, conversionRate } = location.state;
  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

const verifyPayment = async () => {
  setIsVerifying(true);
  try {
    const response = await fetch(`${API_URL}/verify-payment`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ address: "0x123...", amount: 0.05, method: "ETH" }),
    });

    const data = await response.json();
    if (data.success) {
      setIsVerified(true);
      setMessage("Payment Verified! You can now finalize the transaction.");
    } else {
      setMessage("Verification failed. Please try again.");
    }
  } catch (error) {
    setMessage("Error verifying payment. Please check your network and try again.");
    console.error("Error:", error);
  } finally {
    setIsVerifying(false);
    setShowMessageBox(true);
  }
};
  
  
  const handleConfirmTransaction = () => {
    const totalAmount = amount - charge;
    if (!isNaN(balance) && totalAmount > 0) {
      setBalance(balance + totalAmount);
      addTransaction("Deposit", method, totalAmount);
      setMessage("Transaction Successful. Redirecting to Dashboard...");
      setShowMessageBox(true);
      setTimeout(() => navigate("/dashboard"), 3000);
    } else {
      setMessage("Invalid transaction amount.");
      setShowMessageBox(true);
    }
  };

  return (
    <div style={{ padding: "20px", backgroundColor: "red", position: "relative", left: "260px",width: "calc(100% - 260px)" }} >
      <h2>Confirm Deposit</h2>
      <p><strong>Method:</strong> {method}</p>
      <p><strong>Amount:</strong> ${amount.toFixed(2)}</p>
      <p><strong>Charge:</strong> ${charge.toFixed(2)}</p>
      <p><strong>Method Address:</strong> {address}</p>
      <p>
        <strong>Conversion Rate:</strong> 1 {method} = ${conversionRate.toFixed(6)}
      </p>
      <p>
        <strong>Estimated {method}:</strong> {(amount * conversionRate).toFixed(6)} {method}
      </p>

      {!isVerified && (
        <button 
          onClick={verifyPayment} 
          style={{ marginTop: "10px", marginRight: "10px" }} 
          disabled={isVerifying}
        >
          {isVerifying ? "Verifying..." : "Verify Payment"}
        </button>
      )}

      <button onClick={handleConfirmTransaction} style={{ marginTop: "10px" }} disabled={!isVerified}>
        Finalize Transaction
      </button>

      <MessageBox show={showMessageBox} message={message} onClose={() => setShowMessageBox(false)} />
    </div>
  );
};
