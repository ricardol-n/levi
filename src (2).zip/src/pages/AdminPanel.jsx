import React from "react";
import { Admin, Resource } from "react-admin";
import { UserList } from "../admin/UsersList";
import { TransactionList } from "../admin/TransactionsList";
import { WithdrawalList } from "../admin/WithdrawalsList";
import { InvestmentList } from "../admin/InvestmentsList";
import Dashboard from "../admin/AdminDashboard";
import authProvider from "../admin/authProvider";
import dataProvider from "../admin/dataProvider";

const AdminPanel = () => {
    return (
        <Admin 
            dashboard={Dashboard} 
            authProvider={authProvider} 
            dataProvider={dataProvider}
        >
            <Resource name="users" list={UserList} />
            <Resource name="transactions" list={TransactionList} />
            <Resource name="withdrawals" list={WithdrawalList} />
            <Resource name="investments" list={InvestmentList} />
        </Admin>
    );
};

export default AdminPanel;
