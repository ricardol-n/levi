const authProvider = {
    login: ({ username, password }) => {
        if (username === "admin" && password === "admin123") {
            localStorage.setItem("role", "admin");
            return Promise.resolve();
        }
        return Promise.reject("Invalid credentials");
    },
    logout: () => {
        localStorage.removeItem("role");
        return Promise.resolve();
    },
    checkAuth: () => 
        localStorage.getItem("role") === "admin" ? Promise.resolve() : Promise.reject(),
    getPermissions: () => Promise.resolve(localStorage.getItem("role")),
};

export default authProvider;
