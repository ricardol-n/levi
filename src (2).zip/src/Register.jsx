import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import bg1 from './pages/asset/17455.jpg';
import bg2 from './pages/asset/5557528.jpg';
import bg3 from './pages/asset/freepik.jpeg';

const images =[bg1,bg2,bg3];

const RegisterContainer = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: url(${(props) => props.$bgImage}) no-repeat center center/cover;
    transition: background-image 1s ease-in-out;
    height:100vh;
    width:100vw;
    overflow:hidden;
    position:relative;
`;

const FormWrapper = styled.div`
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    padding: 2rem;
    border-radius: 15px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    width: 350px;
    text-align: center;
`;

const Title = styled.h2`
    color: white;
    font-size: 24px;
`;

const Input = styled.input`
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border-radius: 8px;
    border: none;
    outline: none;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    font-size: 16px;

    ::placeholder {
        color: rgba(255, 255, 255, 0.6);
    }
`;

const Button = styled.button`
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 8px;
    background: linear-gradient(45deg, #ff8c00, #ff0080);
    color: white;
    font-size: 18px;
    cursor: pointer;
    transition: 0.3s;

    &:hover {
        transform: scale(1.05);
    }
`;

const ErrorText = styled.p`
    color: red;
    font-size: 14px;
`;

const Register = ({ onRegister }) => {
    const [formData, setFormData] = useState({ email: '', username: '', phone: '' });
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();
    const [currentBg,setCurrentBg] = useState(images[0]);
    const [message,setMessage] = useState(null);

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentBg((prevBg) => {
                const nextIndex = (images.indexOf(prevBg) + 1) % images.length;
                return images[nextIndex];
            });
        }, 5000); // Change image every 5 seconds

        return () => clearInterval(interval);
    }, []);

    const validateForm = () => {
        let newErrors = {};
        if (!formData.email.includes('@')) newErrors.email = 'Invalid email format';
        if (formData.username.length < 3) newErrors.username = 'Username must be at least 3 characters';
        if (formData.phone.length < 10) newErrors.phone = 'Invalid phone number';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (validateForm()) {
            setMessage({ type: 'error', text: "All fields are required." });
            onRegister();
            return;
        }

        localStorage.setItem("user", JSON.stringify(formData));

        setMessage({ type: 'success', text: "Registration successful! Redirecting..." });

        setTimeout(() => {
            navigate("/dashboard"); // Redirect after success
        }, 2000);
    };

    return (
        <RegisterContainer $bgImage={currentBg}>
            <FormWrapper>
                <Title>Register</Title>
                     {message && (
                     <p style={{ color: message.type === "error" ? "red" : "green" }}>
                         {message.text}
                     </p>
                     )}
                <form onSubmit={handleSubmit}>
                    <Input 
                        type="email" 
                        placeholder="Email" 
                        
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })} required
                    />
                    {errors.email && <ErrorText>{errors.email}</ErrorText>}

                    <Input 
                        type="text" 
                        placeholder="Username" 
                        
                        onChange={(e) => setFormData({ ...formData, username: e.target.value })} required
                    />
                    {errors.username && <ErrorText>{errors.username}</ErrorText>}

                    <Input 
                        type="tel" 
                        placeholder="Phone Number" 
                    
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })} required
                    />
                    {errors.phone && <ErrorText>{errors.phone}</ErrorText>}

                    <Button type="submit">Register</Button>
                </form>
            </FormWrapper>
        </RegisterContainer>
    );
};

export default Register;
