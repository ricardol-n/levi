import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import { BalanceProvider } from './BalanceContext.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BalanceProvider>
    <App />
    </BalanceProvider>,
  </StrictMode>,
)
